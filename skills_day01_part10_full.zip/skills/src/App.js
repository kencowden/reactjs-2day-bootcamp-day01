//import logo from './logo.svg';
import { BrowserRouter, Route } from "react-router-dom";
import './styles.css';
import Home from "./components/home/home";
import Customer from "./components/customers/customer";
//
function App() {
  return (
    <div>
      <BrowserRouter>
        <Route exact path="/" component={Home}/>
        <Route path="/customers" component={Customer}/>
      </BrowserRouter>
    </div>
  );
}
//
export default App;
