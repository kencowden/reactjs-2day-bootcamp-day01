import React from "react";
//
function Main(){
    return (
      <main>
        <h2>How to Participate in the Program</h2>
        <p> … </p>
      </main>
    )
  }
//  
export default Main