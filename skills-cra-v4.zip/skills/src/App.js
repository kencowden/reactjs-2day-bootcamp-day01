import './styles.css';
import Home from './components/home/home';
import Customers from './components/customers/customers';
import {BrowserRouter, Route, Routes} from 'react-router-dom';
//
function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
         <Route path="/" element={<Home/>} />
         <Route path="/customers" element={<Customers/>} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
